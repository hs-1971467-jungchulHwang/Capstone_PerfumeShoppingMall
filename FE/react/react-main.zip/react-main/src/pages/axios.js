import React, { useState, useEffect } from 'react';
import axios from "axios";

// async function makeGetRequest () {

//   let res = axios.get ( 'http://webcode.me');

//   let data = res.data;
//   console.log (data);
// }

// makeGetRequest ();